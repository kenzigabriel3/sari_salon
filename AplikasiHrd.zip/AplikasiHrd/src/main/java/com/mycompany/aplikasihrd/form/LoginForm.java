package com.mycompany.aplikasihrd.form;

import com.mycompany.aplikasihrd.config.Database;
import java.awt.*; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder; 

public class LoginForm extends JFrame { 

    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;

    // Colors
    private final Color PRIMARY = new Color(29, 78, 216); // Blue
    private final Color BG_COLOR = new Color(226, 232, 240); // Slightly darker gray for contrast
    private final Color TEXT_DARK = new Color(15, 23, 42);
    private final Color TEXT_MUTED = new Color(100, 116, 139);
    private final Color BORDER_COLOR = new Color(226, 232, 240);

    public LoginForm() {
        setTitle("HR Finance App - Login");
        setSize(550, 750); // Tall and narrow like a modern login card
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_COLOR);

        JPanel mainWrapper = new JPanel(new GridBagLayout());
        mainWrapper.setBackground(BG_COLOR);

        // Main Card
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setPreferredSize(new Dimension(420, 600)); // Fixed size to mimic web card
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(BORDER_COLOR, 1, true),
            new EmptyBorder(40, 40, 40, 40)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.gridx = 0;
        gbc.gridy = 0;
        
        // 1. Logo Icon
        JLabel lblIcon = new JLabel("HR", SwingConstants.CENTER);
        lblIcon.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblIcon.setForeground(Color.WHITE);
        lblIcon.setOpaque(true);
        lblIcon.setBackground(PRIMARY);
        lblIcon.setPreferredSize(new Dimension(50, 50));
        
        JPanel logoWrap = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        logoWrap.setBackground(Color.WHITE);
        logoWrap.add(lblIcon);
        card.add(logoWrap, gbc);

        // 2. App Title
        gbc.gridy++;
        gbc.insets = new Insets(15, 0, 0, 0);
        JLabel title = new JLabel("HR Finance App", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(TEXT_DARK);
        card.add(title, gbc);
        
        // 3. App Subtitle
        gbc.gridy++;
        gbc.insets = new Insets(2, 0, 30, 0);
        JLabel sub = new JLabel("Sistem Manajemen Karyawan", SwingConstants.CENTER);
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(TEXT_MUTED);
        card.add(sub, gbc);

        // 4. Greeting
        gbc.gridy++;
        gbc.insets = new Insets(10, 0, 5, 0);
        JLabel greetTitle = new JLabel("Selamat datang kembali!", SwingConstants.CENTER);
        greetTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        greetTitle.setForeground(TEXT_DARK);
        card.add(greetTitle, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 25, 0);
        JLabel greetSub = new JLabel("Silakan login untuk melanjutkan", SwingConstants.CENTER);
        greetSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        greetSub.setForeground(TEXT_MUTED);
        card.add(greetSub, gbc);

        // 5. Username
        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 5, 0);
        JLabel lblUser = new JLabel("Username");
        lblUser.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblUser.setForeground(TEXT_DARK);
        card.add(lblUser, gbc);
        
        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 15, 0);
        txtUsername = new JTextField();
        styleTextField(txtUsername);
        card.add(txtUsername, gbc);

        // 6. Password
        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 5, 0);
        JLabel lblPass = new JLabel("Password");
        lblPass.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblPass.setForeground(TEXT_DARK);
        card.add(lblPass, gbc);

        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 10, 0);
        txtPassword = new JPasswordField();
        styleTextField(txtPassword);
        card.add(txtPassword, gbc);

        // 7. Options (Remember & Forgot)
        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 20, 0);
        JPanel options = new JPanel(new BorderLayout());
        options.setBackground(Color.WHITE);
        JCheckBox chkRemember = new JCheckBox("Ingat saya");
        chkRemember.setBackground(Color.WHITE);
        chkRemember.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        chkRemember.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        JLabel lblForgot = new JLabel("Lupa password?");
        lblForgot.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblForgot.setForeground(PRIMARY);
        lblForgot.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        options.add(chkRemember, BorderLayout.WEST);
        options.add(lblForgot, BorderLayout.EAST);
        card.add(options, gbc);

        // 8. Login Button
        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 15, 0);
        btnLogin = new JButton("Login");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLogin.setBackground(PRIMARY);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogin.setPreferredSize(new Dimension(0, 42));
        btnLogin.addActionListener(e -> loginAction());
        card.add(btnLogin, gbc);

        // 9. Separator
        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 15, 0);
        JPanel sepPanel = new JPanel(new GridBagLayout());
        sepPanel.setBackground(Color.WHITE);
        GridBagConstraints sGbc = new GridBagConstraints();
        sGbc.fill = GridBagConstraints.HORIZONTAL; sGbc.weightx = 1.0;
        sepPanel.add(new JSeparator(), sGbc);
        sGbc.weightx = 0; sGbc.insets = new Insets(0, 10, 0, 10);
        JLabel lblAtau = new JLabel("atau"); lblAtau.setForeground(TEXT_MUTED); lblAtau.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sepPanel.add(lblAtau, sGbc);
        sGbc.weightx = 1.0; sGbc.insets = new Insets(0, 0, 0, 0);
        sepPanel.add(new JSeparator(), sGbc);
        card.add(sepPanel, gbc);

        // 10. Admin Button
        gbc.gridy++;
        gbc.insets = new Insets(0, 0, 20, 0);
        JButton btnAdmin = new JButton("Login sebagai Admin");
        btnAdmin.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnAdmin.setBackground(Color.WHITE);
        btnAdmin.setForeground(TEXT_DARK);
        btnAdmin.setFocusPainted(false);
        btnAdmin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnAdmin.setPreferredSize(new Dimension(0, 42));
        btnAdmin.setBorder(new LineBorder(BORDER_COLOR, 1, true));
        card.add(btnAdmin, gbc);
        
        // 11. Footer inside card
        gbc.gridy++;
        gbc.insets = new Insets(5, 0, 0, 0);
        JLabel lblFooter = new JLabel("© 2026 HR Finance App", SwingConstants.CENTER);
        lblFooter.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblFooter.setForeground(TEXT_MUTED);
        card.add(lblFooter, gbc);

        // Add card to main wrapper
        mainWrapper.add(card); // Centers it automatically in GridBagLayout

        setContentPane(mainWrapper);
    }
    
    private void styleTextField(JTextField tf) {
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setPreferredSize(new Dimension(0, 42));
        tf.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(BORDER_COLOR, 1, true),
            new EmptyBorder(5, 12, 5, 12)
        ));
    }

    private void loginAction() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());
        
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username dan Password tidak boleh kosong!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection con = Database.getConnection();
             PreparedStatement pst = con.prepareStatement("SELECT * FROM admin WHERE username=? AND password=?")) {

            pst.setString(1, username);
            pst.setString(2, password);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                new DashboardForm().setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Username atau Password salah!", "Login Gagal", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
