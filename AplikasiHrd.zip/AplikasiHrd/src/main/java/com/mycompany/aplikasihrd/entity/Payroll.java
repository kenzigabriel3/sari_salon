package com.mycompany.aplikasihrd.entity;

public class Payroll {
    private int id;
    private int employeeId;
    private double basicSalary;
    private double allowance;

    // Default Constructor
    public Payroll() {
    }

    // Parameterized Constructor
    public Payroll(int id, int employeeId, double basicSalary, double allowance) {
        this.id = id;
        this.employeeId = employeeId;
        this.basicSalary = basicSalary;
        this.allowance = allowance;
    }

    // Encapsulation: Getter & Setter
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public double getAllowance() {
        return allowance;
    }

    public void setAllowance(double allowance) {
        this.allowance = allowance;
    }
}
