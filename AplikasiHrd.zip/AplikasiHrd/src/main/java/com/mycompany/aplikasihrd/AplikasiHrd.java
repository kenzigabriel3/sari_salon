package com.mycompany.aplikasihrd;

import com.mycompany.aplikasihrd.form.LoginForm;

public class AplikasiHrd {
    public static void main(String[] args) {
        // Start the application by displaying the login form
        java.awt.EventQueue.invokeLater(() -> {
            new LoginForm().setVisible(true);
        });
    }
}
