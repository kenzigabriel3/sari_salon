package com.mycompany.aplikasihrd.form;

import com.mycompany.aplikasihrd.config.Database;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

// JasperReports & I/O Imports
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import java.io.InputStream;
import java.io.FileInputStream;

public class DashboardForm extends JFrame {

    // --- Dashboard UI ---
    private JTable tableDashboard;
    private DefaultTableModel modelDashboard;
    private JTextField txtDashName, txtDashPosition, txtDashSalary, txtDashAllowance;
    private JButton btnDashSave, btnDashUpdate, btnDashDelete, btnDashReset;
    private JLabel lblTotalKaryawan, lblTotalGaji, lblTotalTunjangan, lblTotalPengeluaran;
    private List<Integer> dashEmployeeIds = new ArrayList<>();
    private int selectedDashEmployeeId = -1;

    // --- Karyawan UI ---
    private JTable tableKar;
    private DefaultTableModel modelKar;
    private JTextField txtKarName, txtKarPosition;
    private JButton btnKarSave, btnKarUpdate, btnKarDelete, btnKarReset;
    private List<Integer> karEmployeeIds = new ArrayList<>();
    private int selectedKarEmployeeId = -1;

    // --- Gaji UI ---
    private JTable tableGaji;
    private DefaultTableModel modelGaji;
    private JLabel lblGajiEmployeeName;
    private JTextField txtGajiPokok, txtGajiTunjangan;
    private JButton btnGajiUpdate, btnGajiReset;
    private List<Integer> gajiEmployeeIds = new ArrayList<>();
    private int selectedGajiEmployeeId = -1;

    // --- Laporan UI ---
    private JTable tableLap;
    private DefaultTableModel modelLap;
    private JLabel lblLapTotalKaryawan, lblLapTotalPengeluaran;

    // --- Global UI & State ---
    private JLabel lblDate;
    private CardLayout cardLayout;
    private JPanel cardPanel;
    private List<JPanel> menuPanels = new ArrayList<>();
    private List<JLabel> menuLabels = new ArrayList<>();
    private NumberFormat rupiahFormat;
    
    // Colors
    private final Color SIDEBAR_BG = new Color(29, 78, 216);
    private final Color SIDEBAR_HOVER = new Color(37, 99, 235);
    private final Color BG_COLOR = new Color(248, 250, 252);
    private final Color TEXT_DARK = new Color(15, 23, 42);
    private final Color TEXT_MUTED = new Color(100, 116, 139);
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color PRIMARY_BTN = new Color(16, 185, 129); // Emerald
    private final Color WARNING_BTN = new Color(245, 158, 11); // Amber
    private final Color DANGER_BTN = new Color(239, 68, 68); // Red
    
    private final Font FONT_REGULAR = new Font("Segoe UI", Font.PLAIN, 14);
    private final Font FONT_BOLD = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_HEADING = new Font("Segoe UI", Font.BOLD, 18);

    public DashboardForm() {
        rupiahFormat = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
        rupiahFormat.setMaximumFractionDigits(0);

        setTitle("HR Finance App - Dashboard Premium");
        setSize(1366, 768);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel mainWrapper = new JPanel(new BorderLayout());
        
        mainWrapper.add(createSidebar(), BorderLayout.WEST);
        
        JPanel rightArea = new JPanel(new BorderLayout());
        rightArea.setBackground(BG_COLOR);
        rightArea.add(createHeader(), BorderLayout.NORTH);
        
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        
        cardPanel.add(createDashboardPanel(), "Dashboard");
        cardPanel.add(createKaryawanPanel(), "Karyawan");
        cardPanel.add(createGajiPanel(), "Gaji & Tunjangan");
        cardPanel.add(createLaporanPanel(), "Laporan");
        cardPanel.add(createPengaturanPanel(), "Pengaturan");
        
        rightArea.add(cardPanel, BorderLayout.CENTER);
        mainWrapper.add(rightArea, BorderLayout.CENTER);
        add(mainWrapper);

        Timer timer = new Timer(1000, e -> updateClock());
        timer.start();
        updateClock();

        loadAllData();
    }
    
    private void loadAllData() {
        loadDashboardData();
        loadKaryawanData();
        loadGajiData();
        loadLaporanData();
    }

    private void updateClock() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE, d MMMM yyyy  |  HH:mm:ss", new Locale("id", "ID"));
        if(lblDate != null) lblDate.setText(sdf.format(new Date()));
    }

    // =========================================================================
    // SIDEBAR & HEADER
    // =========================================================================
    private JPanel createSidebar() {
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(SIDEBAR_BG);
        sidebar.setPreferredSize(new Dimension(250, 0));
        
        JPanel brandPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 20));
        brandPanel.setBackground(SIDEBAR_BG);
        brandPanel.add(new JLabel("<html><b style='color:white;font-size:16px'>HR Finance App</b><br><span style='color:#bfdbfe;font-size:11px'>Premium System</span></html>"));
        sidebar.add(brandPanel, BorderLayout.NORTH);
        
        menuPanels.clear();
        menuLabels.clear();
        
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        menuPanel.setBackground(SIDEBAR_BG);
        menuPanel.setBorder(new EmptyBorder(10, 0, 0, 0));
        
        menuPanel.add(createMenuItem("Dashboard", true));
        menuPanel.add(createMenuItem("Karyawan", false));
        menuPanel.add(createMenuItem("Gaji & Tunjangan", false));
        menuPanel.add(createMenuItem("Laporan", false));
        menuPanel.add(createMenuItem("Pengaturan", false));
        
        sidebar.add(menuPanel, BorderLayout.CENTER);
        
        JPanel profilePanel = new JPanel(new BorderLayout());
        profilePanel.setBackground(new Color(30, 58, 138));
        profilePanel.setBorder(new EmptyBorder(15, 20, 15, 20));
        profilePanel.add(new JLabel("<html><b style='color:white;font-size:12px'>Admin User</b><br><span style='color:#bfdbfe;font-size:10px'>Administrator</span></html>"), BorderLayout.CENTER);
        sidebar.add(profilePanel, BorderLayout.SOUTH);
        
        return sidebar;
    }
    
    private JPanel createMenuItem(String text, boolean isActive) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 12));
        panel.setBackground(isActive ? SIDEBAR_HOVER : SIDEBAR_BG);
        panel.setMaximumSize(new Dimension(250, 45));
        panel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", isActive ? Font.BOLD : Font.PLAIN, 14));
        label.setForeground(Color.WHITE);
        panel.add(label);
        
        menuPanels.add(panel);
        menuLabels.add(label);
        
        panel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                for (int i = 0; i < menuPanels.size(); i++) {
                    menuPanels.get(i).setBackground(SIDEBAR_BG);
                    menuLabels.get(i).setFont(new Font("Segoe UI", Font.PLAIN, 14));
                }
                panel.setBackground(SIDEBAR_HOVER);
                label.setFont(new Font("Segoe UI", Font.BOLD, 14));
                cardLayout.show(cardPanel, text);
            }
        });
        return panel;
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR),
            new EmptyBorder(15, 30, 15, 30)
        ));
        
        JPanel titlePanel = new JPanel(new GridLayout(2, 1));
        titlePanel.setBackground(Color.WHITE);
        JLabel lblTitle = new JLabel("HR Dashboard");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(TEXT_DARK);
        titlePanel.add(lblTitle);
        titlePanel.add(createMutedLabel("Sistem Manajemen Karyawan Premium"));
        header.add(titlePanel, BorderLayout.WEST);
        
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 5));
        datePanel.setBackground(Color.WHITE);
        lblDate = new JLabel(""); 
        lblDate.setFont(FONT_BOLD);
        lblDate.setForeground(TEXT_DARK);
        
        JPanel dateBox = new JPanel();
        dateBox.setBackground(BG_COLOR);
        dateBox.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_COLOR, 1, true), new EmptyBorder(8, 15, 8, 15)));
        dateBox.add(lblDate);
        datePanel.add(dateBox);
        header.add(datePanel, BorderLayout.EAST);
        
        return header;
    }

    // =========================================================================
    // PANELS: DASHBOARD
    // =========================================================================
    private JPanel createDashboardPanel() {
        JPanel pnl = new JPanel(new BorderLayout(0, 25));
        pnl.setBackground(BG_COLOR);
        pnl.setBorder(new EmptyBorder(25, 30, 25, 30));
        
        // Summary Cards
        JPanel cards = new JPanel(new GridLayout(1, 4, 20, 0));
        cards.setBackground(BG_COLOR);
        lblTotalKaryawan = new JLabel("0"); lblTotalGaji = new JLabel("Rp0");
        lblTotalTunjangan = new JLabel("Rp0"); lblTotalPengeluaran = new JLabel("Rp0");
        cards.add(createCard("Total Karyawan", lblTotalKaryawan, new Color(219, 234, 254), "👥")); 
        cards.add(createCard("Total Gaji Pokok", lblTotalGaji, new Color(209, 250, 229), "💰")); 
        cards.add(createCard("Total Tunjangan", lblTotalTunjangan, new Color(254, 243, 199), "🎁")); 
        cards.add(createCard("Total Pengeluaran", lblTotalPengeluaran, new Color(243, 232, 255), "📈")); 
        pnl.add(cards, BorderLayout.NORTH);
        
        // Split Panel
        JPanel splitPanel = new JPanel(new GridBagLayout());
        splitPanel.setBackground(BG_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1.0;
        
        // Table
        gbc.weightx = 0.73; gbc.gridx = 0; gbc.insets = new Insets(0, 0, 0, 20);
        
        JPanel tableWrap = createWrapperPanel("Data Karyawan Keseluruhan");
        String[] cols = {"No.", "Nama", "Jabatan", "Gaji", "Tunjangan"};
        modelDashboard = new DefaultTableModel(cols, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        tableDashboard = createStyledTable(modelDashboard);
        tableDashboard.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tableDashboard.getSelectedRow() != -1) {
                int row = tableDashboard.getSelectedRow();
                selectedDashEmployeeId = dashEmployeeIds.get(row);
                txtDashName.setText(tableDashboard.getValueAt(row, 1).toString());
                txtDashPosition.setText(tableDashboard.getValueAt(row, 2).toString());
                txtDashSalary.setText(tableDashboard.getValueAt(row, 3).toString().replaceAll("[^\\d]", ""));
                txtDashAllowance.setText(tableDashboard.getValueAt(row, 4).toString().replaceAll("[^\\d]", ""));
            }
        });
        tableWrap.add(new JScrollPane(tableDashboard), BorderLayout.CENTER);
        splitPanel.add(tableWrap, gbc);
        
        // Form
        gbc.weightx = 0.27; gbc.gridx = 1; gbc.insets = new Insets(0, 0, 0, 0);
        JPanel formWrap = new JPanel();
        formWrap.setLayout(new BoxLayout(formWrap, BoxLayout.Y_AXIS));
        formWrap.setBackground(Color.WHITE);
        formWrap.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_COLOR, 1, true), new EmptyBorder(25, 25, 25, 25)));
        
        JLabel lblTitle = new JLabel("Form Quick Add"); lblTitle.setFont(FONT_HEADING);
        lblTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        formWrap.add(lblTitle); formWrap.add(Box.createRigidArea(new Dimension(0, 20)));
        
        formWrap.add(createInputGroup("Nama Karyawan", txtDashName = new JTextField()));
        formWrap.add(createInputGroup("Jabatan", txtDashPosition = new JTextField()));
        formWrap.add(createInputGroup("Gaji Pokok", txtDashSalary = new JTextField()));
        formWrap.add(createInputGroup("Tunjangan", txtDashAllowance = new JTextField()));
        
        btnDashSave = new JButton("Simpan"); styleButton(btnDashSave, PRIMARY_BTN, Color.WHITE);
        btnDashUpdate = new JButton("Update"); styleButton(btnDashUpdate, WARNING_BTN, Color.WHITE);
        btnDashDelete = new JButton("Hapus"); styleButton(btnDashDelete, DANGER_BTN, Color.WHITE);
        btnDashReset = new JButton("Reset"); styleButton(btnDashReset, Color.WHITE, TEXT_DARK); btnDashReset.setBorder(new LineBorder(BORDER_COLOR));
        btnDashReset.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JPanel btns = new JPanel(new GridLayout(1, 3, 10, 0)); btns.setBackground(Color.WHITE);
        btns.setAlignmentX(Component.LEFT_ALIGNMENT);
        btns.add(btnDashSave); btns.add(btnDashUpdate); btns.add(btnDashDelete);
        btns.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btnDashReset.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        
        formWrap.add(btns); formWrap.add(Box.createRigidArea(new Dimension(0, 10))); formWrap.add(btnDashReset);
        formWrap.add(Box.createVerticalGlue());
        
        btnDashSave.addActionListener(e -> saveDashData());
        btnDashUpdate.addActionListener(e -> updateDashData());
        btnDashDelete.addActionListener(e -> deleteDashData());
        btnDashReset.addActionListener(e -> clearDashForm());
        
        splitPanel.add(formWrap, gbc);
        pnl.add(splitPanel, BorderLayout.CENTER);
        return pnl;
    }

    // =========================================================================
    // PANELS: KARYAWAN
    // =========================================================================
    private JPanel createKaryawanPanel() {
        JPanel pnl = new JPanel(new BorderLayout(0, 25));
        pnl.setBackground(BG_COLOR); pnl.setBorder(new EmptyBorder(25, 30, 25, 30));
        
        JPanel titlePanel = new JPanel(new GridLayout(2, 1));
        titlePanel.setBackground(BG_COLOR);
        JLabel lblTitle = new JLabel("Manajemen Karyawan"); lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titlePanel.add(lblTitle); titlePanel.add(createMutedLabel("Kelola data identitas dan jabatan karyawan."));
        pnl.add(titlePanel, BorderLayout.NORTH);
        
        JPanel splitPanel = new JPanel(new GridBagLayout());
        splitPanel.setBackground(BG_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1.0;
        
        gbc.weightx = 0.73; gbc.gridx = 0; gbc.insets = new Insets(0, 0, 0, 20);
        JPanel tableWrap = createWrapperPanel("Daftar Karyawan");
        String[] cols = {"No.", "Nama Lengkap", "Jabatan"};
        modelKar = new DefaultTableModel(cols, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        tableKar = createStyledTable(modelKar);
        tableKar.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tableKar.getSelectedRow() != -1) {
                int row = tableKar.getSelectedRow();
                selectedKarEmployeeId = karEmployeeIds.get(row);
                txtKarName.setText(tableKar.getValueAt(row, 1).toString());
                txtKarPosition.setText(tableKar.getValueAt(row, 2).toString());
            }
        });
        tableWrap.add(new JScrollPane(tableKar), BorderLayout.CENTER);
        splitPanel.add(tableWrap, gbc);
        
        gbc.weightx = 0.27; gbc.gridx = 1; gbc.insets = new Insets(0, 0, 0, 0);
        JPanel formWrap = new JPanel(); formWrap.setLayout(new BoxLayout(formWrap, BoxLayout.Y_AXIS));
        formWrap.setBackground(Color.WHITE); formWrap.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_COLOR, 1, true), new EmptyBorder(25, 25, 25, 25)));
        
        JLabel lblF = new JLabel("Form Data Karyawan"); lblF.setFont(FONT_HEADING);
        lblF.setAlignmentX(Component.LEFT_ALIGNMENT);
        formWrap.add(lblF); formWrap.add(Box.createRigidArea(new Dimension(0, 20)));
        
        formWrap.add(createInputGroup("Nama Lengkap", txtKarName = new JTextField()));
        formWrap.add(createInputGroup("Jabatan", txtKarPosition = new JTextField()));
        
        btnKarSave = new JButton("Simpan"); styleButton(btnKarSave, PRIMARY_BTN, Color.WHITE);
        btnKarUpdate = new JButton("Update"); styleButton(btnKarUpdate, WARNING_BTN, Color.WHITE);
        btnKarDelete = new JButton("Hapus"); styleButton(btnKarDelete, DANGER_BTN, Color.WHITE);
        btnKarReset = new JButton("Reset"); styleButton(btnKarReset, Color.WHITE, TEXT_DARK); btnKarReset.setBorder(new LineBorder(BORDER_COLOR));
        btnKarReset.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        JPanel btns = new JPanel(new GridLayout(1, 3, 10, 0)); btns.setBackground(Color.WHITE);
        btns.setAlignmentX(Component.LEFT_ALIGNMENT);
        btns.add(btnKarSave); btns.add(btnKarUpdate); btns.add(btnKarDelete);
        btns.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40)); btnKarReset.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        
        formWrap.add(btns); formWrap.add(Box.createRigidArea(new Dimension(0, 10))); formWrap.add(btnKarReset);
        formWrap.add(Box.createVerticalGlue());
        
        btnKarSave.addActionListener(e -> saveKarData());
        btnKarUpdate.addActionListener(e -> updateKarData());
        btnKarDelete.addActionListener(e -> deleteKarData());
        btnKarReset.addActionListener(e -> clearKarForm());
        
        splitPanel.add(formWrap, gbc);
        pnl.add(splitPanel, BorderLayout.CENTER);
        return pnl;
    }

    // =========================================================================
    // PANELS: GAJI & TUNJANGAN
    // =========================================================================
    private JPanel createGajiPanel() {
        JPanel pnl = new JPanel(new BorderLayout(0, 25));
        pnl.setBackground(BG_COLOR); pnl.setBorder(new EmptyBorder(25, 30, 25, 30));
        
        JPanel titlePanel = new JPanel(new GridLayout(2, 1)); titlePanel.setBackground(BG_COLOR);
        JLabel lblTitle = new JLabel("Gaji & Tunjangan"); lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titlePanel.add(lblTitle); titlePanel.add(createMutedLabel("Atur besaran gaji pokok dan tunjangan tiap karyawan. (Pilih dari tabel untuk mengedit)"));
        pnl.add(titlePanel, BorderLayout.NORTH);
        
        JPanel splitPanel = new JPanel(new GridBagLayout()); splitPanel.setBackground(BG_COLOR);
        GridBagConstraints gbc = new GridBagConstraints(); gbc.fill = GridBagConstraints.BOTH; gbc.weighty = 1.0;
        
        gbc.weightx = 0.73; gbc.gridx = 0; gbc.insets = new Insets(0, 0, 0, 20);
        JPanel tableWrap = createWrapperPanel("Daftar Penggajian");
        String[] cols = {"No.", "Nama Karyawan", "Gaji Pokok", "Tunjangan", "Total Diterima"};
        modelGaji = new DefaultTableModel(cols, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        tableGaji = createStyledTable(modelGaji);
        tableGaji.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tableGaji.getSelectedRow() != -1) {
                int row = tableGaji.getSelectedRow();
                selectedGajiEmployeeId = gajiEmployeeIds.get(row);
                lblGajiEmployeeName.setText(tableGaji.getValueAt(row, 1).toString());
                txtGajiPokok.setText(tableGaji.getValueAt(row, 2).toString().replaceAll("[^\\d]", ""));
                txtGajiTunjangan.setText(tableGaji.getValueAt(row, 3).toString().replaceAll("[^\\d]", ""));
            }
        });
        tableWrap.add(new JScrollPane(tableGaji), BorderLayout.CENTER);
        splitPanel.add(tableWrap, gbc);
        
        gbc.weightx = 0.27; gbc.gridx = 1; gbc.insets = new Insets(0, 0, 0, 0);
        JPanel formWrap = new JPanel(); formWrap.setLayout(new BoxLayout(formWrap, BoxLayout.Y_AXIS));
        formWrap.setBackground(Color.WHITE); formWrap.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_COLOR, 1, true), new EmptyBorder(25, 25, 25, 25)));
        
        JLabel lblF = new JLabel("Update Nominal"); lblF.setFont(FONT_HEADING);
        lblF.setAlignmentX(Component.LEFT_ALIGNMENT);
        formWrap.add(lblF); formWrap.add(Box.createRigidArea(new Dimension(0, 20)));
        
        // Selected Employee Name Display
        JPanel namePnl = new JPanel(new BorderLayout()); namePnl.setBackground(Color.WHITE);
        namePnl.setAlignmentX(Component.LEFT_ALIGNMENT);
        namePnl.add(createMutedLabel("Karyawan Terpilih:"), BorderLayout.NORTH);
        lblGajiEmployeeName = new JLabel("- Pilih dari tabel -"); lblGajiEmployeeName.setFont(new Font("Segoe UI", Font.BOLD, 16)); lblGajiEmployeeName.setForeground(PRIMARY_BTN);
        namePnl.add(lblGajiEmployeeName, BorderLayout.CENTER);
        namePnl.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        formWrap.add(namePnl); formWrap.add(Box.createRigidArea(new Dimension(0, 15)));
        
        formWrap.add(createInputGroup("Gaji Pokok Baru", txtGajiPokok = new JTextField()));
        formWrap.add(createInputGroup("Tunjangan Baru", txtGajiTunjangan = new JTextField()));
        
        btnGajiUpdate = new JButton("Update Nominal"); styleButton(btnGajiUpdate, WARNING_BTN, Color.WHITE);
        btnGajiReset = new JButton("Batal"); styleButton(btnGajiReset, Color.WHITE, TEXT_DARK); btnGajiReset.setBorder(new LineBorder(BORDER_COLOR));
        
        btnGajiUpdate.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnGajiReset.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnGajiUpdate.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40)); btnGajiReset.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        formWrap.add(btnGajiUpdate); formWrap.add(Box.createRigidArea(new Dimension(0, 10))); formWrap.add(btnGajiReset);
        formWrap.add(Box.createVerticalGlue());
        
        btnGajiUpdate.addActionListener(e -> updateGajiData());
        btnGajiReset.addActionListener(e -> clearGajiForm());
        
        splitPanel.add(formWrap, gbc);
        pnl.add(splitPanel, BorderLayout.CENTER);
        return pnl;
    }

    // =========================================================================
    // PANELS: LAPORAN
    // =========================================================================
    private JPanel createLaporanPanel() {
        JPanel pnl = new JPanel(new BorderLayout(0, 20));
        pnl.setBackground(BG_COLOR); pnl.setBorder(new EmptyBorder(25, 30, 25, 30));
        
        JPanel titlePanel = new JPanel(new BorderLayout()); titlePanel.setBackground(BG_COLOR);
        JPanel tLeft = new JPanel(new GridLayout(2, 1)); tLeft.setBackground(BG_COLOR);
        JLabel lblTitle = new JLabel("Laporan Keuangan & HR"); lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        tLeft.add(lblTitle); tLeft.add(createMutedLabel("Rekapitulasi data karyawan dan beban penggajian perusahaan."));
        titlePanel.add(tLeft, BorderLayout.WEST);
        
        // Mini Summary on right
        JPanel tRight = new JPanel(new GridLayout(2, 1)); tRight.setBackground(BG_COLOR);
        lblLapTotalKaryawan = new JLabel("Total Karyawan: 0", SwingConstants.RIGHT); lblLapTotalKaryawan.setFont(FONT_BOLD);
        lblLapTotalPengeluaran = new JLabel("Total Pengeluaran: Rp0", SwingConstants.RIGHT); lblLapTotalPengeluaran.setFont(FONT_BOLD); lblLapTotalPengeluaran.setForeground(DANGER_BTN);
        tRight.add(lblLapTotalKaryawan); tRight.add(lblLapTotalPengeluaran);
        titlePanel.add(tRight, BorderLayout.EAST);
        
        pnl.add(titlePanel, BorderLayout.NORTH);
        
        JPanel tableWrap = createWrapperPanel("Data Master (Read Only)");
        String[] cols = {"No.", "ID DB", "Nama Karyawan", "Jabatan", "Gaji Pokok", "Tunjangan", "Total Pendapatan"};
        modelLap = new DefaultTableModel(cols, 0) { public boolean isCellEditable(int r, int c) { return false; } };
        tableLap = createStyledTable(modelLap);
        
        tableWrap.add(new JScrollPane(tableLap), BorderLayout.CENTER);
        
        // Action toolbar
        JPanel btnPnl = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        btnPnl.setBackground(Color.WHITE);
        
        JButton btnCsv = new JButton("Unduh CSV");
        styleButton(btnCsv, WARNING_BTN, Color.WHITE);
        btnCsv.addActionListener(e -> exportToCsv());
        
        JButton btnPdf = new JButton("Unduh PDF");
        styleButton(btnPdf, PRIMARY_BTN, Color.WHITE);
        btnPdf.addActionListener(e -> exportToPdf(false));
        
        JButton btnPrintJasper = new JButton("Preview & Cetak (Jasper)");
        styleButton(btnPrintJasper, SIDEBAR_BG, Color.WHITE);
        btnPrintJasper.addActionListener(e -> exportToPdf(true));
        
        btnPnl.add(btnCsv);
        btnPnl.add(btnPdf);
        btnPnl.add(btnPrintJasper);
        tableWrap.add(btnPnl, BorderLayout.SOUTH);
        
        pnl.add(tableWrap, BorderLayout.CENTER);
        return pnl;
    }

    // =========================================================================
    // PANELS: PENGATURAN
    // =========================================================================
    private JPanel createPengaturanPanel() {
        JPanel pnl = new JPanel(new BorderLayout(0, 20));
        pnl.setBackground(BG_COLOR); pnl.setBorder(new EmptyBorder(25, 30, 25, 30));
        
        JLabel lblTitle = new JLabel("Pengaturan Sistem"); lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        pnl.add(lblTitle, BorderLayout.NORTH);
        
        JPanel card = new JPanel(); card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE); card.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_COLOR, 1, true), new EmptyBorder(30, 30, 30, 30)));
        
        card.add(new JLabel("<html><h2>Informasi Aplikasi</h2></html>"));
        card.add(new JLabel("Nama Aplikasi: HR Finance Dashboard Premium"));
        card.add(new JLabel("Versi: 1.0.0"));
        card.add(new JLabel("Author: Admin"));
        card.add(Box.createRigidArea(new Dimension(0, 20)));
        card.add(new JLabel("<html><h2>Status Database</h2></html>"));
        
        JLabel lblDb = new JLabel("Mengecek koneksi...");
        try (Connection con = Database.getConnection()) {
            if (con != null) {
                lblDb.setText("<html>Koneksi: <b style='color:green'>Terhubung ke Supabase PostgreSQL</b></html>");
            } else {
                lblDb.setText("<html>Koneksi: <b style='color:red'>Gagal Terhubung</b></html>");
            }
        } catch (Exception e) {}
        card.add(lblDb);
        
        card.add(Box.createVerticalGlue());
        
        pnl.add(card, BorderLayout.CENTER);
        return pnl;
    }

    // =========================================================================
    // UI HELPERS
    // =========================================================================
    private JPanel createCard(String title, JLabel valueLabel, Color iconColor, String emoji) {
        JPanel card = new JPanel(new BorderLayout(15, 10));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_COLOR, 1, true), new EmptyBorder(20, 20, 20, 20)));
        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 5)); textPanel.setBackground(Color.WHITE);
        textPanel.add(createMutedLabel(title));
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 20)); valueLabel.setForeground(TEXT_DARK);
        textPanel.add(valueLabel);
        
        JLabel lblIcon = new JLabel(emoji, SwingConstants.CENTER); lblIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24));
        JPanel iconBox = new JPanel(new BorderLayout()); iconBox.setBackground(iconColor);
        iconBox.setPreferredSize(new Dimension(55, 55)); iconBox.setBorder(new LineBorder(iconColor, 1, true));
        iconBox.add(lblIcon, BorderLayout.CENTER);
        
        card.add(iconBox, BorderLayout.WEST); card.add(textPanel, BorderLayout.CENTER);
        return card;
    }
    
    private JPanel createWrapperPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout(0, 15));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_COLOR, 1, true), new EmptyBorder(20, 20, 20, 20)));
        JLabel lblTitle = new JLabel(title); lblTitle.setFont(FONT_HEADING); lblTitle.setForeground(TEXT_DARK);
        panel.add(lblTitle, BorderLayout.NORTH);
        return panel;
    }
    
    private JTable createStyledTable(DefaultTableModel model) {
        JTable tbl = new JTable(model);
        tbl.setFont(FONT_REGULAR); tbl.setRowHeight(40);
        tbl.setSelectionBackground(new Color(239, 246, 255)); tbl.setSelectionForeground(TEXT_DARK);
        tbl.setShowVerticalLines(false); tbl.setGridColor(BORDER_COLOR);
        
        JTableHeader header = tbl.getTableHeader();
        header.setFont(FONT_BOLD); header.setBackground(BG_COLOR); header.setForeground(TEXT_MUTED);
        header.setPreferredSize(new Dimension(100, 45)); header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
        ((DefaultTableCellRenderer)header.getDefaultRenderer()).setHorizontalAlignment(JLabel.CENTER);
        
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < tbl.getColumnCount(); i++) {
            tbl.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
        
        tbl.getColumnModel().getColumn(0).setPreferredWidth(40);
        tbl.getColumnModel().getColumn(0).setMaxWidth(60);
        return tbl;
    }
    
    private JPanel createInputGroup(String labelText, JTextField textField) {
        JPanel group = new JPanel(); group.setLayout(new BoxLayout(group, BoxLayout.Y_AXIS)); group.setBackground(Color.WHITE);
        group.setAlignmentX(Component.LEFT_ALIGNMENT); group.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        JLabel lbl = new JLabel(labelText); lbl.setFont(new Font("Segoe UI", Font.BOLD, 12)); lbl.setForeground(TEXT_DARK); lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        textField.setFont(FONT_REGULAR); textField.setAlignmentX(Component.LEFT_ALIGNMENT); textField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 35));
        textField.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER_COLOR, 1, true), new EmptyBorder(5, 10, 5, 10)));
        group.add(lbl); group.add(Box.createRigidArea(new Dimension(0, 5))); group.add(textField); group.add(Box.createRigidArea(new Dimension(0, 15)));
        return group;
    }

    private void styleButton(JButton btn, Color bg, Color fg) {
        btn.setFont(FONT_BOLD); btn.setBackground(bg); btn.setForeground(fg); btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15)); btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    
    private JLabel createMutedLabel(String text) {
        JLabel l = new JLabel(text); l.setFont(new Font("Segoe UI", Font.PLAIN, 13)); l.setForeground(TEXT_MUTED); return l;
    }
    
    private String capitalize(String text) {
        if (text == null || text.isEmpty()) return text;
        String[] words = text.split(" "); StringBuilder result = new StringBuilder();
        for (String word : words) {
            if (word.length() > 0) result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1).toLowerCase()).append(" ");
        }
        return result.toString().trim();
    }

    // =========================================================================
    // DATABASE LOADERS
    // =========================================================================
    private void loadDashboardData() {
        modelDashboard.setRowCount(0); dashEmployeeIds.clear();
        String query = "SELECT e.id, e.name, e.position, p.basic_salary, p.allowance FROM employee e LEFT JOIN payroll p ON e.id = p.employee_id ORDER BY e.id ASC";
        try (Connection con = Database.getConnection(); Statement stmt = con.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            int no = 1;
            while (rs.next()) {
                dashEmployeeIds.add(rs.getInt("id"));
                modelDashboard.addRow(new Object[]{ no++, capitalize(rs.getString("name")), capitalize(rs.getString("position")), 
                    rupiahFormat.format(rs.getDouble("basic_salary")), rupiahFormat.format(rs.getDouble("allowance")) });
            }
            
            // Refresh Summary
            ResultSet rsSum = stmt.executeQuery("SELECT COUNT(id) FROM employee");
            if(rsSum.next()) lblTotalKaryawan.setText(String.valueOf(rsSum.getInt(1)));
            ResultSet rsPay = stmt.executeQuery("SELECT SUM(basic_salary) as total_gaji, SUM(allowance) as total_tunjangan FROM payroll");
            if(rsPay.next()) {
                double gaji = rsPay.getDouble("total_gaji"); double tunjangan = rsPay.getDouble("total_tunjangan");
                lblTotalGaji.setText(rupiahFormat.format(gaji)); lblTotalTunjangan.setText(rupiahFormat.format(tunjangan));
                lblTotalPengeluaran.setText(rupiahFormat.format(gaji + tunjangan));
            }
        } catch (Exception ex) {}
    }

    private void loadKaryawanData() {
        modelKar.setRowCount(0); karEmployeeIds.clear();
        try (Connection con = Database.getConnection(); Statement stmt = con.createStatement(); 
             ResultSet rs = stmt.executeQuery("SELECT id, name, position FROM employee ORDER BY id ASC")) {
            int no = 1;
            while (rs.next()) {
                karEmployeeIds.add(rs.getInt("id"));
                modelKar.addRow(new Object[]{ no++, capitalize(rs.getString("name")), capitalize(rs.getString("position")) });
            }
        } catch (Exception ex) {}
    }

    private void loadGajiData() {
        modelGaji.setRowCount(0); gajiEmployeeIds.clear();
        String query = "SELECT e.id, e.name, COALESCE(p.basic_salary, 0) as basic_salary, COALESCE(p.allowance, 0) as allowance FROM employee e LEFT JOIN payroll p ON e.id = p.employee_id ORDER BY e.id ASC";
        try (Connection con = Database.getConnection(); Statement stmt = con.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            int no = 1;
            while (rs.next()) {
                gajiEmployeeIds.add(rs.getInt("id"));
                double gaji = rs.getDouble("basic_salary"); double tunj = rs.getDouble("allowance");
                modelGaji.addRow(new Object[]{ no++, capitalize(rs.getString("name")), rupiahFormat.format(gaji), rupiahFormat.format(tunj), rupiahFormat.format(gaji+tunj) });
            }
        } catch (Exception ex) {}
    }

    private void loadLaporanData() {
        modelLap.setRowCount(0);
        String query = "SELECT e.id, e.name, e.position, COALESCE(p.basic_salary, 0) as basic_salary, COALESCE(p.allowance, 0) as allowance FROM employee e LEFT JOIN payroll p ON e.id = p.employee_id ORDER BY e.id ASC";
        int totalEmp = 0; double totalPengeluaran = 0;
        try (Connection con = Database.getConnection(); Statement stmt = con.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            int no = 1;
            while (rs.next()) {
                totalEmp++;
                double gaji = rs.getDouble("basic_salary"); double tunj = rs.getDouble("allowance"); totalPengeluaran += (gaji + tunj);
                modelLap.addRow(new Object[]{ no++, rs.getInt("id"), capitalize(rs.getString("name")), capitalize(rs.getString("position")), 
                    rupiahFormat.format(gaji), rupiahFormat.format(tunj), rupiahFormat.format(gaji+tunj) });
            }
            lblLapTotalKaryawan.setText("Total Karyawan: " + totalEmp);
            lblLapTotalPengeluaran.setText("Total Pengeluaran: " + rupiahFormat.format(totalPengeluaran));
        } catch (Exception ex) {}
    }

    // =========================================================================
    // CRUD: DASHBOARD
    // =========================================================================
    private void clearDashForm() {
        txtDashName.setText(""); txtDashPosition.setText(""); txtDashSalary.setText(""); txtDashAllowance.setText("");
        tableDashboard.clearSelection(); selectedDashEmployeeId = -1;
    }
    private void saveDashData() {
        if (txtDashName.getText().trim().isEmpty()) return;
        try (Connection con = Database.getConnection()) {
            con.setAutoCommit(false);
            try {
                int newId = -1;
                try (PreparedStatement pst = con.prepareStatement("INSERT INTO employee (name, position) VALUES (?, ?) RETURNING id")) {
                    pst.setString(1, txtDashName.getText().trim()); pst.setString(2, txtDashPosition.getText().trim());
                    ResultSet rs = pst.executeQuery(); if (rs.next()) newId = rs.getInt(1);
                }
                if (newId != -1) {
                    try (PreparedStatement pst = con.prepareStatement("INSERT INTO payroll (employee_id, basic_salary, allowance) VALUES (?, ?, ?)")) {
                        pst.setInt(1, newId); pst.setDouble(2, Double.parseDouble(txtDashSalary.getText().trim())); pst.setDouble(3, Double.parseDouble(txtDashAllowance.getText().trim()));
                        pst.executeUpdate();
                    }
                }
                con.commit(); JOptionPane.showMessageDialog(this, "Tersimpan!"); clearDashForm(); loadAllData();
            } catch (Exception e) { con.rollback(); }
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Angka tidak valid!"); }
    }
    private void updateDashData() {
        if (selectedDashEmployeeId == -1) return;
        try (Connection con = Database.getConnection()) {
            con.setAutoCommit(false);
            try {
                try (PreparedStatement pst = con.prepareStatement("UPDATE employee SET name=?, position=? WHERE id=?")) {
                    pst.setString(1, txtDashName.getText().trim()); pst.setString(2, txtDashPosition.getText().trim()); pst.setInt(3, selectedDashEmployeeId); pst.executeUpdate();
                }
                try (PreparedStatement pst = con.prepareStatement("UPDATE payroll SET basic_salary=?, allowance=? WHERE employee_id=?")) {
                    pst.setDouble(1, Double.parseDouble(txtDashSalary.getText().trim())); pst.setDouble(2, Double.parseDouble(txtDashAllowance.getText().trim())); pst.setInt(3, selectedDashEmployeeId); pst.executeUpdate();
                }
                con.commit(); JOptionPane.showMessageDialog(this, "Ter-update!"); clearDashForm(); loadAllData();
            } catch (Exception e) { con.rollback(); }
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Angka tidak valid!"); }
    }
    private void deleteDashData() {
        if (selectedDashEmployeeId == -1) return;
        if (JOptionPane.showConfirmDialog(this, "Hapus?", "Hapus", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try (Connection con = Database.getConnection()) {
                try (PreparedStatement p1 = con.prepareStatement("DELETE FROM payroll WHERE employee_id=?"); PreparedStatement p2 = con.prepareStatement("DELETE FROM employee WHERE id=?")) {
                    p1.setInt(1, selectedDashEmployeeId); p1.executeUpdate(); p2.setInt(1, selectedDashEmployeeId); p2.executeUpdate();
                }
                JOptionPane.showMessageDialog(this, "Terhapus!"); clearDashForm(); loadAllData();
            } catch (Exception e) {}
        }
    }

    // =========================================================================
    // CRUD: KARYAWAN
    // =========================================================================
    private void clearKarForm() {
        txtKarName.setText(""); txtKarPosition.setText("");
        tableKar.clearSelection(); selectedKarEmployeeId = -1;
    }
    private void saveKarData() {
        if (txtKarName.getText().trim().isEmpty()) return;
        try (Connection con = Database.getConnection()) {
            con.setAutoCommit(false);
            try {
                int newId = -1;
                try (PreparedStatement pst = con.prepareStatement("INSERT INTO employee (name, position) VALUES (?, ?) RETURNING id")) {
                    pst.setString(1, txtKarName.getText().trim()); pst.setString(2, txtKarPosition.getText().trim());
                    ResultSet rs = pst.executeQuery(); if (rs.next()) newId = rs.getInt(1);
                }
                if (newId != -1) {
                    try (PreparedStatement pst = con.prepareStatement("INSERT INTO payroll (employee_id, basic_salary, allowance) VALUES (?, 0, 0)")) {
                        pst.setInt(1, newId); pst.executeUpdate();
                    }
                }
                con.commit(); JOptionPane.showMessageDialog(this, "Karyawan Tersimpan!"); clearKarForm(); loadAllData();
            } catch (Exception e) { con.rollback(); }
        } catch (Exception e) {}
    }
    private void updateKarData() {
        if (selectedKarEmployeeId == -1) return;
        try (Connection con = Database.getConnection(); PreparedStatement pst = con.prepareStatement("UPDATE employee SET name=?, position=? WHERE id=?")) {
            pst.setString(1, txtKarName.getText().trim()); pst.setString(2, txtKarPosition.getText().trim()); pst.setInt(3, selectedKarEmployeeId);
            pst.executeUpdate(); JOptionPane.showMessageDialog(this, "Karyawan Diupdate!"); clearKarForm(); loadAllData();
        } catch (Exception e) {}
    }
    private void deleteKarData() {
        if (selectedKarEmployeeId == -1) return;
        if (JOptionPane.showConfirmDialog(this, "Hapus Karyawan?", "Hapus", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try (Connection con = Database.getConnection()) {
                try (PreparedStatement p1 = con.prepareStatement("DELETE FROM payroll WHERE employee_id=?"); PreparedStatement p2 = con.prepareStatement("DELETE FROM employee WHERE id=?")) {
                    p1.setInt(1, selectedKarEmployeeId); p1.executeUpdate(); p2.setInt(1, selectedKarEmployeeId); p2.executeUpdate();
                }
                JOptionPane.showMessageDialog(this, "Karyawan Terhapus!"); clearKarForm(); loadAllData();
            } catch (Exception e) {}
        }
    }

    // =========================================================================
    // CRUD: GAJI
    // =========================================================================
    private void clearGajiForm() {
        txtGajiPokok.setText(""); txtGajiTunjangan.setText(""); lblGajiEmployeeName.setText("- Pilih dari tabel -");
        tableGaji.clearSelection(); selectedGajiEmployeeId = -1;
    }
    private void updateGajiData() {
        if (selectedGajiEmployeeId == -1) { JOptionPane.showMessageDialog(this, "Pilih karyawan dulu!"); return; }
        try (Connection con = Database.getConnection(); PreparedStatement pst = con.prepareStatement("UPDATE payroll SET basic_salary=?, allowance=? WHERE employee_id=?")) {
            pst.setDouble(1, Double.parseDouble(txtGajiPokok.getText().trim())); pst.setDouble(2, Double.parseDouble(txtGajiTunjangan.getText().trim()));
            pst.setInt(3, selectedGajiEmployeeId);
            int updated = pst.executeUpdate();
            if (updated == 0) {
                // If payroll row didn't exist for some reason, insert it
                try(PreparedStatement pstIns = con.prepareStatement("INSERT INTO payroll (employee_id, basic_salary, allowance) VALUES (?, ?, ?)")) {
                    pstIns.setInt(1, selectedGajiEmployeeId); pstIns.setDouble(2, Double.parseDouble(txtGajiPokok.getText().trim())); pstIns.setDouble(3, Double.parseDouble(txtGajiTunjangan.getText().trim()));
                    pstIns.executeUpdate();
                }
            }
            JOptionPane.showMessageDialog(this, "Gaji Diupdate!"); clearGajiForm(); loadAllData();
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Angka tidak valid!"); }
    }

    private void exportToPdf(boolean previewOnly) {
        try (Connection con = Database.getConnection()) {
            if (con == null) {
                JOptionPane.showMessageDialog(this, "Gagal menghubungkan ke database!", "Koneksi Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            InputStream reportStream = getClass().getResourceAsStream("/reports/laporan_hrd.jrxml");
            if (reportStream == null) {
                // Fallback: try loading from file system
                java.io.File fallbackFile = new java.io.File("src/main/resources/reports/laporan_hrd.jrxml");
                if (fallbackFile.exists()) {
                    reportStream = new java.io.FileInputStream(fallbackFile);
                } else {
                    JOptionPane.showMessageDialog(this, "Template laporan (laporan_hrd.jrxml) tidak ditemukan!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            
            // Compile
            JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);
            
            // Parameters
            java.util.Map<String, Object> parameters = new java.util.HashMap<>();
            
            // Fill
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, con);
            
            if (previewOnly) {
                // Show in JasperViewer
                JasperViewer viewer = new JasperViewer(jasperPrint, false);
                viewer.setTitle("Preview Laporan Keuangan & HR");
                viewer.setLocationRelativeTo(this);
                viewer.setVisible(true);
            } else {
                // Save dialog
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Simpan Laporan PDF");
                fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("PDF Document (*.pdf)", "pdf"));
                fileChooser.setSelectedFile(new java.io.File("Laporan_Keuangan_HR_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date()) + ".pdf"));
                
                int userSelection = fileChooser.showSaveDialog(this);
                if (userSelection == JFileChooser.APPROVE_OPTION) {
                    java.io.File fileToSave = fileChooser.getSelectedFile();
                    String filePath = fileToSave.getAbsolutePath();
                    if (!filePath.toLowerCase().endsWith(".pdf")) {
                        filePath += ".pdf";
                    }
                    
                    // Export
                    JasperExportManager.exportReportToPdfFile(jasperPrint, filePath);
                    
                    JOptionPane.showMessageDialog(this, 
                        "Laporan berhasil diunduh dalam format PDF!\nPath: " + filePath, 
                        "Download Sukses", 
                        JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal memproses laporan: " + ex.getMessage(), "Error Laporan", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void exportToCsv() {
        if (tableLap.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk diekspor!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Simpan Rekap Data CSV");
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("CSV File (*.csv)", "csv"));
        fileChooser.setSelectedFile(new java.io.File("Rekap_Data_HR_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date()) + ".csv"));
        
        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            java.io.File fileToSave = fileChooser.getSelectedFile();
            String filePath = fileToSave.getAbsolutePath();
            if (!filePath.toLowerCase().endsWith(".csv")) {
                filePath += ".csv";
            }
            
            try (java.io.BufferedWriter writer = new java.io.BufferedWriter(new java.io.OutputStreamWriter(new java.io.FileOutputStream(filePath), "UTF-8"))) {
                // Write UTF-8 BOM for Excel
                writer.write('\ufeff');
                
                // Headers
                for (int i = 0; i < tableLap.getColumnCount(); i++) {
                    writer.write(escapeCsv(tableLap.getColumnName(i)));
                    if (i < tableLap.getColumnCount() - 1) {
                        writer.write(";");
                    }
                }
                writer.newLine();
                
                // Data
                for (int i = 0; i < tableLap.getRowCount(); i++) {
                    for (int j = 0; j < tableLap.getColumnCount(); j++) {
                        Object val = tableLap.getValueAt(i, j);
                        writer.write(escapeCsv(val != null ? val.toString() : ""));
                        if (j < tableLap.getColumnCount() - 1) {
                            writer.write(";");
                        }
                    }
                    writer.newLine();
                }
                
                // Summary info
                writer.newLine();
                writer.write("Total Karyawan;;;;;;" + escapeCsv(lblLapTotalKaryawan.getText().replace("Total Karyawan: ", "")));
                writer.newLine();
                writer.write("Total Pengeluaran;;;;;;" + escapeCsv(lblLapTotalPengeluaran.getText().replace("Total Pengeluaran: ", "")));
                writer.newLine();
                
                JOptionPane.showMessageDialog(this, 
                    "Rekap data berhasil diunduh dalam format CSV!\nPath: " + filePath, 
                    "Download Sukses", 
                    JOptionPane.INFORMATION_MESSAGE);
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Gagal menyimpan file CSV: " + ex.getMessage(), "Error Ekspor", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private String escapeCsv(String value) {
        if (value == null) {
            return "";
        }
        if (value.contains(";") || value.contains("\"") || value.contains("\n") || value.contains("\r")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }
}
