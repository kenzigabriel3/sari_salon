Interpretasi Sistem Informasi Manajemen HRD dan Penggajian Karyawan (HR Finance App)

Disusun Oleh :
Kenzie Gabriel		[NIM Anda]
	









FAKULTAS TEKNOLOGI INFORMASI DAN KOMUNIKASI
PROGRAM STUDI TEKNIK INFORMATIKA / SOFTWARE ENGINEERING
INSTITUTE TEKNOLOGI DAN BISNIS BINA SARANA GLOBAL
2026




BAB I
PENDAHULUAN
1.1 Latar Belakang
Setiap perusahaan atau instansi, sekecil apapun itu, pasti butuh banget yang namanya pengelolaan data karyawan dan perhitungan gaji tiap bulannya. Urusan keuangan dan HRD ini bukan hal sepele — di baliknya ada banyak detail krusial seperti penentuan gaji pokok, pemberian tunjangan, hingga rekapitulasi total pengeluaran operasional perusahaan. Kalau pencatatannya berantakan atau ga akurat, dampaknya bisa fatal ke urusan keuangan perusahaan.
Sayangnya, masih banyak tempat usaha yang mengelola data HRD dan gaji karyawan pake cara lama: catat di kertas, buku kas manual, atau paling banter pake spreadsheet Excel di satu laptop admin. Cara-cara ini emang gampang, tapi kelemahannya banyak banget. Data gampang ilang, salah ketik nominal, susah rekap total pengeluaran bulanan, dan datanya ga bisa diakses dari tempat lain. Pas akhir bulan tiba, bagian keuangan bakal pusing tujuh keliling buat rekap gaji satu-satu secara manual.
Di era sekarang, teknologi udah makin canggih dengan adanya penyimpanan data berbasis internet (cloud) yang bisa diakses secara real-time kapan saja. Salah satunya adalah Supabase — platform yang nyediain database PostgreSQL online secara gratis dan bisa langsung kita konekin ke aplikasi yang kita bikin tanpa harus sewa server sendiri yang mahal. Ini jadi peluang bagus buat bikin sistem HRD dan penggajian yang lebih modern, cepat, dan datanya aman tersimpan di internet.
Dari situlah kita bikin ide untuk merancang **Sistem Informasi Manajemen HRD dan Penggajian Karyawan (HR Finance App)** ini. Aplikasi ini berbasis desktop menggunakan Java, terkoneksi langsung ke database Supabase di internet menggunakan JDBC Driver, dan dilengkapi fitur komplit mulai dari manajemen data karyawan, pengaturan gaji pokok dan tunjangan, pencarian data, sampai cetak laporan rekapitulasi gaji dalam format PDF dan CSV. Dengan aplikasi ini, urusan rekap gaji bulanan jadi lebih praktis, data rapi, dan laporan bisa diunduh kapan saja cuma sekali klik.

1.2 Rumusan Masalah
Berdasarkan latar belakang di atas, ada beberapa masalah yang pengen diselesaikan lewat aplikasi ini:
1.  Bagaimana cara merancang aplikasi desktop yang bisa mengelola data karyawan dan keuangan penggajian yang langsung terkoneksi ke database cloud Supabase?
2.  Bagaimana cara melakukan proses tambah, lihat, ubah, dan hapus (CRUD) data karyawan beserta gaji pokok dan tunjangannya secara aman melalui aplikasi?
3.  Bagaimana cara menghasilkan laporan rekapitulasi gaji karyawan yang rapi dan bisa langsung diunduh dalam format PDF serta CSV tanpa acak-acakan?

1.3 Tujuan
Tujuan dari pembuatan proyek aplikasi ini adalah:
1.  Membuat aplikasi desktop berbasis Java Swing untuk mengelola database karyawan dan rincian gaji secara terintegrasi.
2.  Menghubungkan aplikasi secara langsung ke cloud database Supabase agar data sinkron secara real-time dan aman dari risiko kehilangan data lokal.
3.  Menyediakan form input terpadu (*Quick Add*) untuk mempercepat tugas administrasi harian HRD.
4.  Menyediakan fitur unduh laporan rekapitulasi dalam format PDF (menggunakan JasperReports) dan CSV agar mudah dicetak atau diolah kembali datanya.

1.4 Manfaat
Manfaat yang bisa diperoleh dari aplikasi ini antara lain:
*   **Bagi Admin HRD / Keuangan**:
    *   Proses input data karyawan baru dan nominal gaji bulanan jadi lebih praktis tanpa perlu mencatat manual lagi.
    *   Rekap total pengeluaran gaji dan tunjangan otomatis dihitung oleh sistem pada tampilan layar.
    *   Bisa mencetak dokumen laporan formal PDF secara instan kapan saja dibutuhkan.
*   **Bagi Manajemen Perusahaan**:
    *   Mendapatkan sajian data pengeluaran gaji karyawan yang akurat dan rapi.
    *   Memudahkan evaluasi beban pengeluaran gaji bulanan perusahaan.
*   **Bagi Pengembang (Mahasiswa)**:
    *   Mendapatkan pemahaman langsung tentang cara menghubungkan aplikasi Java dengan cloud database PostgreSQL menggunakan driver JDBC.
    *   Belajar mengimplementasikan pustaka JasperReports untuk pembuatan dokumen PDF dinamis dari database.
    *   Mampu menganalisis celah sistem aplikasi melalui analisis kesenjangan (Gap Analysis) untuk pengembangan ke depan.

1.5 Ruang Lingkup
Biar pembahasan ga melebar, aplikasi ini dibatasi pada ruang lingkup sebagai berikut:
*   **Fitur yang Disediakan**:
    *   Pengelolaan data karyawan (tambah, lihat, ubah, dan hapus nama serta jabatan).
    *   Pengelolaan data gaji pokok dan tunjangan (input dan update nominal).
    *   Tampilan ringkasan statistik (total karyawan, total gaji pokok, total tunjangan, dan total seluruh pengeluaran) secara langsung di Dashboard.
    *   Tabel laporan master data secara *read-only* untuk mencegah manipulasi data secara tidak sengaja di tab Laporan.
    *   Ekspor laporan ke berkas PDF (JasperReports) dan CSV (titik koma `;` delimiter).
*   **Fitur yang Tidak Disediakan**:
    *   Fitur absensi harian (kehadiran masuk-pulang) karyawan.
    *   Sistem keamanan/login aktif di frontend (meskipun tabel `admin` sudah disiapkan di database).
    *   Perhitungan potongan pajak gaji (PPh 21), BPJS, atau denda keterlambatan.


BAB II
CARA KERJA SISTEM DAN STRUKTUR DATABASE
2.1 Alur Kerja Aplikasi (Arsitektur Sistem)
Aplikasi HR Finance App ini dibuat dengan menghubungkan program Java di komputer admin (Client) langsung ke cloud server database di internet (Supabase Cloud). Tujuannya biar data ga gampang ilang kalo komputer admin rusak, dan datanya bisa diakses secara real-time.
Secara garis besar, cara kerja aplikasi dibagi menjadi 4 komponen utama:
1.  **Antarmuka Dashboard (Java Swing)**: Ini adalah tampilan halaman utama aplikasi yang dipakai admin buat nginput, ngedit, atau ngehapus data karyawan dan gaji secara visual.
2.  **Konektor Database (JDBC Driver)**: Driver PostgreSQL JDBC yang bertugas sebagai jembatan untuk mengirimkan data/query SQL dari aplikasi ke database online secara instan lewat jaringan internet.
3.  **Database Cloud (Supabase PostgreSQL)**: Tempat penyimpanan terpusat untuk menampung tabel data admin, tabel data karyawan, dan data penggajian.
4.  **Fitur Ekspor Laporan**: Bagian sistem yang bertugas mengolah data dari database menjadi file eksternal berupa PDF formal siap cetak (JasperReports) atau file Excel (CSV) biasa.

Berikut adalah gambar alur flowchart aplikasi sebelum program dijalankan:

![Flowchart Aplikasi HR Finance](flowchart_system.png)

2.1.1 Penjelasan Cabang-Cabang Alur Diagram (Flowchart)
Berdasarkan diagram flowchart yang udah dibikin, alur kerja sistem dibagi jadi beberapa bagian:
*   **Platform**: Aplikasi ini dibuat sebagai program desktop (Java executable) yang bisa dijalankan di berbagai sistem operasi (Windows, macOS, Linux). Agar berjalan optimal dan tampilan GUI ga rusak, disarankan pake OS Windows 10/11 dengan Java Runtime Environment (JRE) terbaru.
*   **Teknologi**: Tampilan halaman GUI dirancang menggunakan Java Swing di software NetBeans IDE. Beberapa library penting dipasang di file `pom.xml`:
    *   `postgresql` driver (versi 42.7.3) buat koneksi Java ke database Supabase.
    *   `jasperreports` (versi 6.21.3) buat nge-compile file template `.jrxml` dan mengekspornya jadi file PDF.
*   **Database**: Database PostgreSQL di-host secara online di Supabase. Database ini punya 3 tabel utama yang saling berelasi: tabel `admin` untuk akun login, tabel `employee` untuk data identitas karyawan, dan tabel `payroll` untuk nominal gaji pokok dan tunjangan.
*   **Struktur Program**: Susunan source code diatur rapi ke dalam beberapa package di dalam NetBeans:
    *   `com.mycompany.aplikasihrd.config`: Berkas `Database.java` buat ngatur string koneksi JDBC ke Supabase.
    *   `com.mycompany.aplikasihrd.form`: Berkas `DashboardForm.java` yang merupakan file GUI utama tempat seluruh logika tampilan dan aksi tombol berada.
    *   `reports`: Folder resources tempat menyimpan berkas desain laporan cetak `laporan_hrd.jrxml`.

2.1.2 Mengapa Aplikasi Ini Didesain Seperti Ini?
Kalau ada yang nanya kenapa arsitektur aplikasinya dibikin kayak gini, berikut alasan logisnya:
*   **Kenapa Pake Database Cloud (Supabase)?**: Kalau database disimpen lokal di komputer admin (pake XAMPP/MySQL biasa), datanya bakal ilang permanen kalau harddisk komputer rusak atau kena virus. Dengan Supabase, data aman di cloud server internet dan bisa diakses bareng-bareng oleh admin lain dari laptop berbeda.
*   **Kenapa Dibuat Aplikasi Desktop (Bukan Website)?**: Aplikasi desktop berbasis Swing sangat stabil dan responsif buat nginput data dalam jumlah banyak secara harian. Aplikasi desktop juga ga butuh hosting web berbayar dan bisa langsung berinteraksi dengan printer kantor untuk keperluan cetak fisik.
*   **Kenapa File Program Dipisah (Config, Form, Resources)?**: Biar kalau ada error gampang dicari. Misalnya, kalau koneksi database bermasalah, kita tinggal cek package `config` aja. Kalau tombol di layar ga fungsi, kita tinggal buka package `form`. Jadi kode program ga numpuk di satu file tunggal yang bikin pusing.
*   **Kenapa Menyediakan PDF dan CSV Sekaligus?**: Karena tujuannya beda. File PDF dipake buat dokumen resmi yang layout-nya rapi, ada tanda tangan, dan siap dicetak buat diserahin ke bos. Sedangkan file CSV/Excel dipake admin buat ngolah angka-angka gaji lagi secara manual (misal buat kalkulasi rumus bonus atau laporan pajak tahunan).

2.2 Desain Database (Struktur Tabel Data)
Data dalam aplikasi ini disimpan dalam tiga tabel utama di internet yang saling terhubung: data akun (`admin`), data karyawan (`employee`), dan data gaji/tunjangan (`payroll`).

2.2.1 Hubungan Antar-Tabel (ERD)
Keterkaitan antar-tabel dalam database digambarkan melalui diagram relasi dari Supabase Schema Visualizer berikut:

![Skema Database Supabase](supabase_schema.png)

Penjelasan relasi tabel database di atas:
*   **Tabel `employee` ke `payroll`**: Satu karyawan (`employee`) terhubung ke satu data gaji (`payroll`). Hubungan ini diikat oleh field `employee_id` di tabel `payroll` yang bertindak sebagai *Foreign Key* yang merujuk ke field `id` di tabel `employee`.
*   **Tabel `admin`**: Berdiri sendiri karena hanya digunakan sebagai penyimpan data akun untuk validasi autentikasi akses aplikasi di masa mendatang.


BAB III
IMPLEMENTASI DAN PEMBAHASAN FITUR UTAMA
3.1 Fitur 1: Tampilan Dashboard Utama
Tampilan Dashboard dirancang dengan gaya yang modern, rapi, dan responsif. Aplikasi ini menggunakan tata letak panel sidebar di sebelah kiri untuk navigasi menu, dan panel konten di sebelah kanan menggunakan `CardLayout`.

Di halaman **Dashboard** konten utama, kita nampilin:
*   **Kartu Ringkasan (Summary Cards)**: Menampilkan total karyawan, total gaji pokok, total tunjangan, dan total pengeluaran secara otomatis dengan perhitungan dinamis dari database.
*   **Tabel Data Karyawan Keseluruhan**: Tabel yang memuat data seluruh karyawan beserta gajinya.
*   **Form Quick Add**: Form instan di sebelah kanan tabel untuk melakukan penambahan (*Save*), pembaruan (*Update*), penghapusan (*Delete*), dan pembersihan form (*Reset*) secara cepat.

Tampilan antarmuka laporan pada aplikasi disajikan secara rapi pada gambar di bawah ini:

![Tampilan Menu Laporan](app_ui_laporan.png)

3.2 Fitur 2: Pengelolaan Data Karyawan dan Gaji (CRUD)
Logika CRUD ini diimplementasikan langsung pada kelas `DashboardForm.java` yang terhubung langsung ke database PostgreSQL Supabase.

3.2.1 Tambah Data (Create)
Fitur ini dipake buat nambah data karyawan baru beserta nominal gajinya sekaligus.
*   **Alur Kerja**: Admin mengisi nama, jabatan, gaji pokok, dan tunjangan pada form *Quick Add*, lalu klik tombol **Simpan**.
*   **Logika Program**: 
    1. Program bakal matiin fitur *Auto Commit* koneksi (`con.setAutoCommit(false)`) buat mastiin transaksi database aman (konsep *database transaction*).
    2. Program jalanin query insert pertama: `INSERT INTO employee (name, position) VALUES (?, ?) RETURNING id` untuk dapet nomor ID karyawan yang baru dibuat.
    3. Setelah dapet ID-nya, program lanjut ngejalanin query insert kedua: `INSERT INTO payroll (employee_id, basic_salary, allowance) VALUES (?, ?, ?)` menggunakan ID baru tersebut.
    4. Kalo kedua proses insert sukses tanpa error, program bakal jalanin `con.commit()` dan nampilin pop-up sukses. Kalo ada yang gagal, program bakal jalanin `con.rollback()` biar ga ada data gantung.

3.2.2 Tampil Data (Read)
Fitur ini otomatis jalan pas aplikasi pertama kali dibuka atau tiap kali ada perubahan data.
*   **Alur Kerja**: Aplikasi menarik data ter-update dari database dan memasukkannya ke dalam tabel visual.
*   **Logika Program**: Program jalanin query SQL gabungan `SELECT e.id, e.name, e.position, p.basic_salary, p.allowance FROM employee e LEFT JOIN payroll p ON e.id = p.employee_id ORDER BY e.id ASC`. Data hasil query dibaca baris demi baris, lalu dimasukkan ke dalam model tabel (`DefaultTableModel`) yang terikat dengan JTable di layar.

3.2.3 Edit Data (Update)
Fitur ini dipake buat ganti nama, jabatan, atau nominal gaji pokok dan tunjangan karyawan.
*   **Alur Kerja**: Admin klik baris karyawan yang mau diedit di tabel. Form otomatis terisi dengan data yang dipilih. Admin ganti datanya, terus klik tombol **Update**.
*   **Logika Program**: Program jalanin query update secara paralel menggunakan ID karyawan terpilih:
    *   `UPDATE employee SET name=?, position=? WHERE id=?`
    *   `UPDATE payroll SET basic_salary=?, allowance=? WHERE employee_id=?`
    Setelah berhasil, data tabel di dashboard langsung otomatis ter-refresh.

3.2.4 Hapus Data (Delete)
Fitur ini dipake buat ngapus data karyawan yang udah keluar dari perusahaan.
*   **Alur Kerja**: Admin klik baris karyawan, pencet tombol **Hapus**, lalu klik 'Yes' pada kotak konfirmasi hapus data.
*   **Logika Program**: Karena tabel `payroll` punya relasi *Foreign Key* ke tabel `employee`, kita ga bisa langsung ngapus data karyawan begitu aja karena bakal kena error *foreign key constraint*. Solusinya, program bakal ngehapus dulu data gajinya di tabel `payroll` (`DELETE FROM payroll WHERE employee_id=?`), barulah setelah itu program aman buat ngehapus data identitas karyawannya di tabel `employee` (`DELETE FROM employee WHERE id=?`).


BAB IV
IMPLEMENTASI FITUR LAPORAN JASPERREPORT & CSV
4.1 Gambaran Umum Fitur Laporan
Dalam pengelolaan keuangan administrasi HRD, fitur buat ekspor laporan sangatlah penting. Pada tab menu **Laporan**, data master disajikan dalam format tabel *read-only* (hanya bisa dibaca) buat menghindari admin ga sengaja ngedit data di menu laporan. 
Di bagian bawah menu Laporan ini, kita nyediain 3 opsi tombol ekspor:
*   **Unduh CSV**: Buat nge-ekspor data laporan mentah ke format CSV biar gampang dibuka di Microsoft Excel atau WPS Office.
*   **Unduh PDF**: Buat bikin file dokumen PDF yang layout-nya rapi secara instan.
*   **Preview & Cetak (Jasper)**: Buat ngebuka layar pratinjau cetak secara interaktif pake tool bawaan JasperReports.

4.2 Integrasi Unduh PDF (JasperReports)
4.2.1 Mekanisme Kerja Cetak PDF
Proses pembuatan file PDF dilakukan secara dinamis menggunakan template cetak berbasis JRXML yang diolah oleh library JasperReports:
1.  **Pemuatan File JRXML**: Aplikasi bakal nyari file cetak `laporan_hrd.jrxml` yang ada di dalam resources project. Kalo ga ketemu, program punya sistem pertahanan (*fallback*) buat nyari di folder file system `src/main/resources/reports/laporan_hrd.jrxml`.
2.  **Kompilasi Laporan**: Menggunakan kelas `JasperCompileManager.compileReport()`, template JRXML di-compile menjadi objek laporan Jasper.
3.  **Pengisian Data (Filling)**: Menggunakan `JasperFillManager.fillReport()`, objek laporan diisi dengan data real-time langsung dari database PostgreSQL Supabase melalui koneksi database aktif (`con`).
4.  **Ekspor Berkas**: Untuk tombol "Unduh PDF", program bakal ngebuka dialog simpan file (`JFileChooser`). Begitu nama file dan lokasi ditentukan, program panggil `JasperExportManager.exportReportToPdfFile()` buat nulis filenya ke komputer lokal.
5.  **Preview Laporan**: Untuk tombol "Preview & Cetak", program panggil `JasperViewer` untuk nampilin jendela pratinjau laporan secara visual agar admin bisa langsung print lewat mesin printer kantor.

4.3 Penerapan Ekspor Excel (CSV)
4.3.1 Mekanisme Kerja Ekspor CSV
Ekspor data ke format CSV dibikin secara manual menggunakan writer bawaan Java (`BufferedWriter`) agar prosesnya cepat dan ringan.

Mekanisme kerjanya adalah sebagai berikut:
1.  **Menulis Kode BOM UTF-8**: Program menuliskan karakter khusus BOM (Byte Order Mark) `\ufeff` di baris paling pertama file. Tujuannya adalah biar Microsoft Excel atau WPS Office otomatis tahu kalau file tersebut pake encoding UTF-8, sehingga simbol mata uang Rupiah ("Rp") dan titik ribuan tidak rusak atau berganti menjadi karakter aneh saat dibuka.
2.  **Menulis Judul Kolom (Header)**: Program memutar kolom tabel dan menuliskan judul kolomnya dengan dipisahkan oleh karakter titik koma (`;`).
3.  **Menulis Baris Data**: Program memutar setiap baris JTable, mengambil datanya, lalu menulisnya ke file dengan pemisah titik koma (`;`).
4.  **Pembersihan Karakter (Escape CSV)**: Kalo ada data yang mengandung tanda kutip ganda (`"`), baris baru (`\n`), atau titik koma (`;`), program bakal ngebungkus data tersebut pake tanda kutip ganda agar susunan kolom CSV tidak berantakan.
5.  **Penyelarasan Ringkasan (Summary Info)**: Teks summary 'Total Karyawan' dan 'Total Pengeluaran' ditulis di baris paling bawah. Biar rapi dan teksnya tidak terpotong (clipped) akibat kolom pertama ("No.") yang sempit, program meletakkan nilai totalnya di Kolom G (kolom terakhir) dengan cara menyelipkan 6 buah titik koma sebelumnya (`Total Karyawan;;;;;;4`). Ini bikin kolom B sampai F kosong, sehingga teks di kolom A otomatis melebar (overflow) ke kanan dengan rapi tanpa terpotong di Excel.

*Catatan: Kita menggunakan titik koma (`;`) sebagai delimiter/pemisah kolom, bukan koma (`,`). Karena di komputer dengan regional pengaturan Indonesia (WPS Office/Excel Indonesia), pemisah kolom default yang dipakai adalah titik koma. Dengan begitu, pas file CSV diunduh dan diklik dua kali, datanya langsung kepisah otomatis ke dalam kolom-kolom tanpa perlu disetting manual.*

4.4 Notifikasi Ekspor Berhasil
Untuk memberikan umpan balik (feedback) yang jelas bagi pengguna, aplikasi dilengkapi dengan notifikasi pop-up dialog menggunakan `JOptionPane.showMessageDialog`.
*   Notifikasi ini bakal muncul begitu file PDF atau CSV selesai ditulis ke komputer lokal.
*   Pesan notifikasi menampilkan lokasi absolut tempat file disimpan agar admin tahu persis di mana file laporan tersebut berada.
*   Pesan notifikasi menggunakan tipe `JOptionPane.INFORMATION_MESSAGE` yang menampilkan ikon info "i" berwarna biru standar untuk memberi kenyamanan visual bagi pengguna.


BAB V
GAP ANALYSIS
5.1 Analisis Evaluasi Sistem Aplikasi Saat Ini (Gap Analysis)
Analisis kesenjangan ini dibuat untuk mengukur perbedaan antara kondisi sistem yang ada saat ini dengan kondisi ideal yang diharapkan di masa depan:

| No | Fitur / Bagian Aplikasi | Kondisi Aplikasi Sekarang (Current State) | Kondisi yang Diharapkan (Expected State) | Kesenjangan (Gap) & Rencana Solusi |
| :--- | :--- | :--- | :--- | :--- |
| **1** | **Autentikasi Pengguna (Login)** | Aplikasi langsung menampilkan Dashboard begitu dibuka tanpa ada halaman login. | Hanya admin terdaftar di tabel `admin` yang bisa mengakses dashboard demi keamanan data keuangan. | Keamanan data masih sangat rawan. Solusinya, di versi berikutnya harus diaktifkan form login di awal dengan memvalidasi username dan password ke tabel `admin`. |
| **2** | **Keamanan Kredensial Database** | Informasi host, database, user, dan password Supabase ditulis mentah di dalam source code Java. | Kredensial database tersimpan aman dan tidak bisa dilihat oleh orang lain. | Bahaya dekompilasi file `.class`. Rencana solusinya adalah menyembunyikan kredensial di file konfigurasi terpisah (`.env` atau `.properties`) yang tidak masuk ke dalam source code aplikasi. |
| **3** | **Sinkronisasi Data Real-time** | Data baru muncul di tabel setelah reload otomatis dari aksi CRUD lokal. Jika ada admin lain yang mengedit data di komputer berbeda, data tidak otomatis sinkron. | Data pada tabel JTable otomatis ter-update secara langsung (real-time) begitu ada perubahan di cloud database. | Data bisa *out-of-sync*. Solusi ke depan adalah memasang fitur listener websocket atau background thread timer untuk menyegarkan data otomatis tiap beberapa detik. |
| **4** | **Pengelolaan Input Penggajian** | Input nominal gaji pokok dan tunjangan masih dilakukan manual per satu karyawan secara berulang. | Admin bisa menginputkan atau menaikkan gaji secara massal untuk efisiensi waktu kerja. | Input data masih kaku. Solusi ke depan adalah membuat fitur *Batch Update* (misal menaikkan tunjangan semua karyawan jabatan 'Staff' secara serentak). |

5.2 Gap Analysis Fitur Laporan
Evaluasi khusus dilakukan pada sistem pelaporan untuk memetakan kesenjangan fungsional pada fitur unduh PDF dan CSV:

| No | Fitur / Bagian Laporan | Kondisi Laporan Sekarang (Current State) | Kondisi yang Diharapkan (Expected State) | Kesenjangan (Gap) & Rencana Solusi |
| :--- | :--- | :--- | :--- | :--- |
| **1** | **Fleksibilitas Delimiter CSV** | File CSV dikunci menggunakan delimiter titik koma (`;`) untuk menyesuaikan regional Indonesia. | File CSV bisa dibuka dengan rapi di komputer dengan regional US (yang pake koma `,`) maupun regional Indo (pake `;`). | CSV tidak universal. Solusinya adalah membuat dropdown pilihan delimiter di menu Pengaturan sebelum mengunduh file CSV. |
| **2** | **Filter Data Cetak** | Aplikasi mengekspor seluruh isi database ke dalam laporan PDF/CSV sekaligus. | Admin bisa memfilter data terlebih dahulu (misal cetak gaji bulan tertentu atau divisi tertentu saja). | Laporan terlalu menumpuk. Solusinya adalah menambahkan komponen tanggal dan dropdown jabatan di tab Laporan untuk dijadikan parameter filter query SQL sebelum dicetak. |
| **3** | **Kustomisasi Kop Surat Laporan** | Kop surat laporan PDF (nama dinas/perusahaan, alamat, logo) bersifat statis di template JRXML. | Kop surat dan nama pimpinan penandatangan laporan bisa diubah-ubah secara dinamis langsung dari aplikasi. | Laporan kaku untuk multi-cabang. Solusi ke depan adalah membuat tabel pengaturan instansi di database untuk di-passing sebagai parameter dinamis ke JasperReports. |
| **4** | **Ekspor Excel Asli (.xlsx)** | Format ekspor tabel dinamis baru tersedia dalam bentuk file teks CSV. | Laporan bisa diekspor langsung ke berkas Excel asli (`.xlsx`) lengkap dengan tabel berwarna dan rumus matematika. | CSV tidak mendukung gaya tabel. Solusi ke depan adalah mengintegrasikan pustaka **Apache POI** agar aplikasi bisa membuat berkas spreadsheet `.xlsx` yang profesional. |


BAB VI
PENUTUP
6.1 Kesimpulan
Berdasarkan pengerjaan, pengujian, dan analisis aplikasi HR Finance App ini, diperoleh beberapa kesimpulan sebagai berikut:
1.  **Fungsionalitas Berjalan Baik**: Aplikasi HR Finance App berhasil dibuat dengan membagi menu navigasi ke dalam beberapa kartu menu (`Dashboard`, `Karyawan`, `Gaji & Tunjangan`, dan `Laporan`) menggunakan Swing GUI yang responsif.
2.  **Koneksi Cloud Berhasil**: Aplikasi berhasil terhubung secara online dengan cloud database Supabase PostgreSQL menggunakan JDBC Driver, sehingga penyimpanan data bersifat terpusat dan aman.
3.  **CRUD Berjalan Sinkron**: Proses tambah, lihat, ubah, dan hapus data karyawan beserta rincian penggajiannya terbukti berjalan dengan sinkron langsung ke database. Penanganan hapus data dilakukan dengan alur menghapus tabel anak (`payroll`) terlebih dahulu baru tabel induk (`employee`) untuk menghindari error relasional.
4.  **Laporan Rapi dan Kompatibel**: Fitur laporan berhasil diimplementasikan dengan dua cara. Laporan PDF via JasperReports menghasilkan layout dokumen resmi. Sedangkan Laporan CSV diperbaiki menggunakan pembatas titik koma (`;`) dan penataan baris summary di kolom G, sehingga langsung rapi dan tidak terpotong saat dibuka di WPS Office atau Excel Indonesia.

6.2 Saran
Beberapa saran yang dapat diajukan untuk pengembangan aplikasi di masa mendatang adalah:
1.  **Aktifkan Login Form**: Menambahkan form login autentikasi di awal aplikasi agar data keuangan perusahaan tidak bisa diakses atau diubah oleh sembarang orang.
2.  **Filter Parameter Laporan**: Menambahkan komponen filter pencarian data (misal pencarian nama atau filter berdasarkan jabatan) di menu laporan sebelum tombol cetak ditekan agar cetakan dokumen lebih efisien.
3.  **Enkripsi Kredensial**: Memindahkan string koneksi database dari source code ke berkas eksternal terenkripsi demi keamanan database cloud dari risiko dekompilasi program.
4.  **Integrasi Apache POI**: Memasang library Apache POI untuk mendukung ekspor dokumen ke format Microsoft Excel asli (`.xlsx`) dengan format tabel yang berwarna dan interaktif.


DAFTAR PUSTAKA
[1] Oracle Corporation, "Java Swing Documentation," 2026. [Online]. Available: https://docs.oracle.com/javase/tutorial/uiswing/. [Diakses: 22 Juni 2026].
[2] PostgreSQL Global Development Group, "PostgreSQL JDBC Driver Documentation," 2026. [Online]. Available: https://jdbc.postgresql.org/documentation/. [Diakses: 22 Juni 2026].
[3] TIBCO Software Inc., "JasperReports Library Overview," 2026. [Online]. Available: https://community.jaspersoft.com/project/jasperreports-library. [Diakses: 22 Juni 2026].
