package com.mycompany.aplikasihrd.entity;

public class Admin {
    private int id;
    private String username;
    private String password;

    // Default Constructor
    public Admin() {
    }

    // Constructor with parameters
    public Admin(int id, String username, String password) {
        this.id = id;
        this.username = username;
        this.password = password;
    }

    // Encapsulation (Getters and Setters)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
