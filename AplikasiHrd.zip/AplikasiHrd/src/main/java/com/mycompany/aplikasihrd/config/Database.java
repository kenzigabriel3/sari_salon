package com.mycompany.aplikasihrd.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
    private static final String URL = "jdbc:postgresql://aws-1-ap-southeast-2.pooler.supabase.com:6543/postgres?prepareThreshold=0";
    private static final String USER = "postgres.qianvfnokqivtefwdmzs";
    private static final String PASSWORD = "Kenzi_190204"; // Pastikan ini benar password database Anda

    public static Connection getConnection() {
        try {
            // Register driver
            Class.forName("org.postgresql.Driver");
            // Selalu buka koneksi baru (aman untuk try-with-resources)
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Koneksi Database Gagal: " + e.getMessage());
            return null;
        }
    }
}
